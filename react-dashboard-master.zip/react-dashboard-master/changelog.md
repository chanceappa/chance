# Changelog

## [1.5.0] - 14/09/2023

- Added react-scripts version 5 along with webpack version 5 support.
- Added support for node.js version > 20
- Updated React.js from 16 to 18 version
- Removed old webpack configs.
- Removed unnecessary dev dependencies.
- Replaced deprecated glyphicons-halflings icon library with bootstrap-icons

## [1.4.2] - 22/12/2023

- Updated dependencies

## [1.4.1]
 
### Updated
- Added link to flatlogic on login page

## [1.4.0]
 
### Updated
- Update libs, fixed text visibility

## [1.3.0]
 
### Updated
- Update libs
 
## [1.2.0]
 
### Updated
- Update libs
- Merge PR 
 
## [1.1.0]

### Updated

Following libs have beed updated to the recent versions:
- React - 16.7.1
- React-router - 4.3.1
- Reactstrap - 7.1.0

## [1.0.0]

### New Features

- Shadow added to image
